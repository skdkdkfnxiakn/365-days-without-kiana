// Backend proxy: keep OPENAI_API_KEY on the server, never in browser/mobile source.
import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
dotenv.config();
const app=express();
const __dirname=path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(__dirname,'public')));
app.post('/api/coach',async(req,res)=>{
  try{
    if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'روی سرور متغیر OPENAI_API_KEY تنظیم نشده است.'});
    const {message,context='',profile={},history=[]}=req.body||{};
    if(!message||typeof message!=='string')return res.status(400).json({error:'پیام خالی است.'});
    const safeHistory=Array.isArray(history)?history.slice(-12).map(m=>({role:m.role==='user'?'user':'assistant',content:String(m.text||'').slice(0,5000)})):[];
    const instructions=`تو مربی شخصی برنامه «365 روز بدون کیانا» هستی. فارسی روان و محترمانه بنویس. ابتدا شناخت مرحله‌ای انجام بده، یک سؤال روشن در هر نوبت بپرس، از قضاوت و وعده قطعی خودداری کن. بر اساس وقت، بودجه، خواب، کار و هدف‌های فرد برنامه واقع‌بینانه و قابل پیگیری بده. اگر اطلاعات کم است سؤال بپرس. برای مالی توصیه عمومی و حساب‌وکتاب شفاف ارائه کن، ادعای تخصصی یا تشخیص پزشکی نکن. پاسخ‌ها ساده و عملی باشند. اطلاعاتی که کاربر وارد می‌کند را محرمانه فرض کن و درخواست اطلاعات بسیار حساس نکن.`;
    const input=[...safeHistory,{role:'user',content:`پیام فعلی: ${message}\nزمینه و اطلاعاتی که کاربر در اختیار برنامه گذاشته:\n${String(context).slice(0,12000)}\nپروفایل: ${JSON.stringify(profile).slice(0,4000)}`}];
    const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-5-mini',instructions,input,store:false})});
    const data=await response.json();
    if(!response.ok)return res.status(response.status).json({error:data.error?.message||'درخواست API ناموفق بود.'});
    const reply=(data.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join('\n').trim();
    res.json({reply:reply||'پاسخی دریافت نشد.'});
  }catch(e){res.status(500).json({error:'خطای سرور: '+e.message})}
});
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`365 Days AI server running on port ${port}`));
